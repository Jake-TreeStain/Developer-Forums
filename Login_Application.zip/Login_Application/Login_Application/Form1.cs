﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Application
{
    public partial class Form : System.Windows.Forms.Form
    {
        public Form()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button_register_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This has not been added yet, Ask Jake to make you an account.", "Message",MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


        private void password_box_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                button_login.PerformClick();
        }

        private void username_box_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                password_box.Focus();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(username_box.Text))
            {
                MessageBox.Show("Please enter your Username.","Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                username_box.Focus();
                return;

            }
            try
            {
                AppDataTableAdapters.usersTableAdapter user = new AppDataTableAdapters.usersTableAdapter();
                AppData.usersDataTable dt = user.Login(username_box.Text, password_box.Text);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Welcome", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Process your login here

                    NextPage();

                }
                else
                    MessageBox.Show("Your username or password is incorrect.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void NextPage()
        {
            //MainForum nextpage = new MainForum();
            //nextpage.ShowDialog();
        }
    }
}
