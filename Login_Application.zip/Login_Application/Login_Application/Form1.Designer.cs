﻿namespace Login_Application
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.username_text = new System.Windows.Forms.Label();
            this.password_text = new System.Windows.Forms.Label();
            this.button_register = new System.Windows.Forms.Button();
            this.password_box = new System.Windows.Forms.TextBox();
            this.username_box = new System.Windows.Forms.TextBox();
            this.button_login = new System.Windows.Forms.Button();
            this.Please_Login = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // username_text
            // 
            this.username_text.AutoSize = true;
            this.username_text.BackColor = System.Drawing.Color.Transparent;
            this.username_text.Font = new System.Drawing.Font("American Captain", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_text.ForeColor = System.Drawing.Color.White;
            this.username_text.Location = new System.Drawing.Point(12, 129);
            this.username_text.Name = "username_text";
            this.username_text.Size = new System.Drawing.Size(83, 26);
            this.username_text.TabIndex = 1;
            this.username_text.Text = "Username";
            this.username_text.Click += new System.EventHandler(this.label1_Click);
            // 
            // password_text
            // 
            this.password_text.AutoSize = true;
            this.password_text.BackColor = System.Drawing.Color.Transparent;
            this.password_text.Font = new System.Drawing.Font("American Captain", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_text.ForeColor = System.Drawing.Color.White;
            this.password_text.Location = new System.Drawing.Point(12, 155);
            this.password_text.Name = "password_text";
            this.password_text.Size = new System.Drawing.Size(86, 26);
            this.password_text.TabIndex = 2;
            this.password_text.Text = "Password";
            this.password_text.Click += new System.EventHandler(this.label2_Click);
            // 
            // button_register
            // 
            this.button_register.BackColor = System.Drawing.SystemColors.Control;
            this.button_register.Font = new System.Drawing.Font("American Captain", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_register.ForeColor = System.Drawing.Color.Black;
            this.button_register.Location = new System.Drawing.Point(161, 298);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(111, 51);
            this.button_register.TabIndex = 6;
            this.button_register.Text = "Register";
            this.button_register.UseVisualStyleBackColor = false;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // password_box
            // 
            this.password_box.Location = new System.Drawing.Point(108, 159);
            this.password_box.Name = "password_box";
            this.password_box.Size = new System.Drawing.Size(159, 20);
            this.password_box.TabIndex = 1;
            this.password_box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.password_box_KeyPress);
            // 
            // username_box
            // 
            this.username_box.Location = new System.Drawing.Point(108, 133);
            this.username_box.Name = "username_box";
            this.username_box.Size = new System.Drawing.Size(159, 20);
            this.username_box.TabIndex = 0;
            this.username_box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.username_box_KeyPress);
            // 
            // button_login
            // 
            this.button_login.BackColor = System.Drawing.SystemColors.Control;
            this.button_login.Font = new System.Drawing.Font("American Captain", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button_login.ForeColor = System.Drawing.Color.Black;
            this.button_login.Location = new System.Drawing.Point(12, 298);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(111, 51);
            this.button_login.TabIndex = 2;
            this.button_login.Text = "Login";
            this.button_login.UseVisualStyleBackColor = false;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // Please_Login
            // 
            this.Please_Login.AutoSize = true;
            this.Please_Login.BackColor = System.Drawing.Color.Transparent;
            this.Please_Login.Font = new System.Drawing.Font("American Captain", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Please_Login.ForeColor = System.Drawing.Color.White;
            this.Please_Login.Location = new System.Drawing.Point(8, 9);
            this.Please_Login.Name = "Please_Login";
            this.Please_Login.Size = new System.Drawing.Size(132, 24);
            this.Please_Login.TabIndex = 7;
            this.Please_Login.Text = "Please Login Below";
            // 
            // Form
            // 
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Login_Application.Properties.Resources.RGSStudios_Background3;
            this.ClientSize = new System.Drawing.Size(284, 361);
            this.Controls.Add(this.Please_Login);
            this.Controls.Add(this.button_register);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.password_box);
            this.Controls.Add(this.password_text);
            this.Controls.Add(this.username_text);
            this.Controls.Add(this.username_box);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximumSize = new System.Drawing.Size(300, 400);
            this.Name = "Form";
            this.Text = "RGS Studios || Login";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label username_text;
        private System.Windows.Forms.Label password_text;
        private System.Windows.Forms.Button button_register;
        private System.Windows.Forms.TextBox password_box;
        private System.Windows.Forms.TextBox username_box;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.Label Please_Login;
    }
}

